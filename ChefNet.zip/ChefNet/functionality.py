import pandas as pd

'''def getIngredients(dishName):
    recipe_df = pd.read_csv('data/data.csv', header = 0)
    rList = []
    if not recipe_df[recipe_df['Class Name'] == dishName].empty:
        row = recipe_df.loc[recipe_df['Class Name'] == dishName, ['Ingredients']].iloc[0]

        rList.append(row['Ingredients'].split('@') if 'Ingredients' in row else [])

    print(rList)
    return rList'''


def getIngredients(dishName):
    recipe_df = pd.read_csv('data/data.csv', header=0)
    rList = []

    if dishName in recipe_df['Class Name'].values:
        row = recipe_df.loc[recipe_df['Class Name'] == dishName, 'Ingredients'].iloc[0]
        rList.extend(row.split('@') if isinstance(row, str) else [])

    return rList


def getRecipe(dishName):
    recipe_df = pd.read_csv('data/data.csv', header=0)
    rList = []
    if not recipe_df[recipe_df['Class Name'] == dishName].empty:
        row = recipe_df.loc[recipe_df['Class Name'] == dishName, ['Recipe']].iloc[0]

        rList.append(row['Recipe'].split('@') if 'Recipe' in row else [])

    return rList
