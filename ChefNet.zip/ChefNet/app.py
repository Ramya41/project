import os

from flask import Flask, render_template, request

import functionality
import model

dishName = ''
confidenceScore = 0
imgName = ''


def cleanDirectory():
    directory_path = 'static/dish/'

    try:
        for filename in os.listdir(directory_path):
            file_path = os.path.join(directory_path, filename)
            os.remove(file_path)
            print(f"The file {file_path} has been deleted successfully.")
        print(f"All files in the directory {directory_path} have been deleted.")
    except FileNotFoundError:
        print(f"The directory {directory_path} does not exist.")
    except PermissionError:
        print(f"You do not have permission to delete files in the directory {directory_path}.")
    except Exception as e:
        print(f"An error occurred: {e}")


app = Flask(__name__)


@app.route('/')
def index():
    cleanDirectory()
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload():
    global dishName, confidenceScore, imgName
    if 'file' in request.files:
        file = request.files['file']
        if file.filename != '':
            imgName = file.filename
            file.save(os.path.join('static/dish', file.filename))

    result = model.identifyDish(imgName)
    dishName = result[0][:-1]
    confidenceScore = result[1]
    print(f'Dish {dishName} and Confidence {round(confidenceScore * 100, 4)}%')

    return render_template('recipe-generator.html')


@app.route('/about-us')
def about_us():
    return render_template('about.html')


@app.route('/home-remedies')
def home_remedies():
    return render_template('home-remedies.html')


@app.route('/home-remedies/cold')
def cold():
    return render_template('cold.html')


@app.route('/home-remedies/cough')
def cough():
    return render_template('cough.html')


@app.route('/home-remedies/fever')
def fever():
    return render_template('fever.html')


@app.route('/home-remedies/indigestion')
def indigestion():
    return render_template('indigestion.html')


@app.route('/home-remedies/constipation')
def constipation():
    return render_template('constipation.html')


@app.route('/home-remedies/acne')
def acne():
    return render_template('acne.html')


@app.route('/home-remedies/sore-throat')
def throat():
    return render_template('throat.html')


@app.route('/home-remedies/nausea')
def nausea():
    return render_template('nausea.html')


@app.route('/contact-us')
def contact_us():
    return render_template('contact.html')


@app.route('/nutritional-info')
def nutritional_information():
    return render_template('nutri-info.html')


@app.route('/recipe-generator')
def recipe_generator():
    cleanDirectory()
    return render_template('recipe-generator.html')


@app.route('/results')
def recipe():
    global dishName

    # Initialize lists
    ingredientsList = functionality.getIngredients(dishName)

    recipeList = functionality.getRecipe(dishName)
    return render_template('recipe-output.html', imageName='dish/' + imgName, dishName=dishName,
                           confidenceScore=str(round(confidenceScore * 100, 4)) + '%', ingredients=ingredientsList,
                           recipe=recipeList[0])


@app.route('/nutrition')
def nutrition():
    global dishName
    return render_template('nutrition.html', dishName=dishName, imageName="dish-images/" + dishName + ".png")


@app.route('/bmi-calculator')
def bmi():
    return render_template('bmi.html')


@app.route('/calculate_bmi', methods=['POST'])
def calculate_bmi():
    height = float(request.form['height'])
    weight = float(request.form['weight'])
    unit = request.form['unit']

    if unit == 'metric':
        height /= 100

    if unit == 'imperial':
        height *= 0.0254
        weight *= 0.453592

    # Calculate BMI
    bmi = round(weight / (height ** 2), 2)

    return render_template('bmi.html', bmi=bmi)


@app.route('/daily-calories')
def calorie():
    return render_template('calorie.html')


@app.route('/calculate-calories', methods=['POST'])
def calculate_calories():
    height = float(request.form['height'])
    weight = float(request.form['weight'])
    age = int(request.form['age'])
    sex = request.form['sex']
    unit = request.form['units']
    activity = request.form['activity_level']

    if unit == "Imperial":
        weight *= 0.453592
        height *= 2.54

    if sex == 'male':
        bmr = int((10 * weight) + (6.25 * height) - (5 * age) + 5)
    else:
        bmr = int((10 * weight) + (6.25 * height) - (5 * age) - 161)

    if activity == 'sedentary':
        bmr *= 1.2
    elif activity == 'light':
        bmr *= 1.375
    elif activity == 'moderate':
        bmr *= 1.55
    elif activity == 'active':
        bmr *= 1.725
    elif activity == 'extra-active':
        bmr *= 1.9
    else:
        pass

    bmr = int(bmr)

    return render_template('calorie.html', bmr=bmr)


if __name__ == '__main__':
    app.run(debug=True)
